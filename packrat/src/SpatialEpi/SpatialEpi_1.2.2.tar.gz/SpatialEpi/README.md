SpatialEpi
==========

Methods and Data for Spatial Epidemiology
