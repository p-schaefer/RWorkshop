tsa.combined<-function(benthic.metric,add.mets=F, env.data, distance=NULL,
                       outlier.rem=T, m.select=T,rank=F,na.cutoff=0.7,
                       k=NULL, adaptive=T, RDA.reference=NULL) {
  
}