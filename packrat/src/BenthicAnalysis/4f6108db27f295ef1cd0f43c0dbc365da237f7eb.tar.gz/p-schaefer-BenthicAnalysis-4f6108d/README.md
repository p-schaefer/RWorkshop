# BenthicAnalysis

An R package for analysis of Benthic Macroinvertebrate data. Package is under heavy development, please contact Patrick Schaefer (patrick.schaefer@mail.utoronto.ca) before attempting to use. 
