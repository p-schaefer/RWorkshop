
//typedef int int64_t ;

#ifdef _MSC_VER
	typedef __int64 int64_t ;
#else
	#include <stdint.h>

	//typedef long long int int64_t ;
#endif
