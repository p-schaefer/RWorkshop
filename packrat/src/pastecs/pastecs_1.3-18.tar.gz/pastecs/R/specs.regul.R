"specs.regul" <-
function(x, ...) {
	structure(x$specs, class="specs.regul")
}
