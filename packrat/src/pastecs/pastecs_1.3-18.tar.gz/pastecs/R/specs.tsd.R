"specs.tsd" <-
function(x, ...) {
	structure(x$specs, class="specs.tsd")
}
