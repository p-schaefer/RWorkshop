"summary.regul" <-
function(object, ...)
	structure(object, class=c("summary.regul", class(object)))
