"extract" <-
function (e, n, ...)
	UseMethod("extract")
