"summary.turnpoints" <-
function(object, ...)
	structure(object, class=c("summary.turnpoints", class(object)))
