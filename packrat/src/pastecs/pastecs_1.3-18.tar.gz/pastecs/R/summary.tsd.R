"summary.tsd" <-
function(object, ...)
	structure(object, class=c("summary.tsd", class(object)))
