"summary.escouf" <-
function(object, ...)
	structure(object, class=c("summary.escouf", class(object)))
