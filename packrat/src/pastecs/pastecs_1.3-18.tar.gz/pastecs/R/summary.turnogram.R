"summary.turnogram" <-
function(object, ...)
	structure(object, class=c("summary.turnogram", class(object)))
