"summary.abund" <-
function(object, ...)
	structure(object, class=c("summary.abund", class(object)))
