"print.stat.slide" <-
function(x, ...) {
	print(x$stat)
	invisible(x)
}
