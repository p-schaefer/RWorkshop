"is.tseries" <-
function(x) {
	is.ts(x)
}
