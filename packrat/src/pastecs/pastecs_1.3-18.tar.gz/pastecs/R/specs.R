"specs" <-
function(x, ...)
	UseMethod("specs")
